
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import java.util.Iterator; //<--- NB: import from java.util
/**
 * Bank class containing an ArrayList of Customers and 
 * a HashMap associating customers to their account numbers
 * 
 * @author jfitzgerald
 * 
 */
public class BIABank
{
  ArrayList<Customer> customers = new ArrayList<>();
  HashMap<Integer, Customer> customerRecord = new HashMap<>();
  HashSet<Integer> accountNumberSet = new HashSet<>(); //<-------added set account numbers
  private static int INITIAL_ACCOUNT_NUMBER = 1000;
  /**
   * nextAccountNumber is the next available account number and is assigned to a
   * new customer It is a class variable rather than an instance variable since
   * the value requires visibility across all BIABank objects
   */
  static int nextAccountNumber = INITIAL_ACCOUNT_NUMBER;

  public int newCustomer(String name, int balance)
  {
    int accountNumber = nextAccountNumber;
    if(accountNumberSet.contains(accountNumber) == true) //<---- check unique account number
    {
      System.out.println("Fatal error: invalid account number generated");
    }
    accountNumberSet.add(accountNumber);//<------- account number unique so add it to set
    Customer newCustomer = new Customer(name, accountNumber, balance);
    customers.add(newCustomer);
    customerRecord.put(accountNumber, newCustomer);
    nextAccountNumber += 1;
    return accountNumber;
  }

  public String getCustomerName(int accountNumber)
  {
    Customer customer = customerRecord.get(accountNumber);
    if(customer != null) 
    {
      return customer.getName();
    }
    else 
    {
      return "Customer with account number "+accountNumber+" does not exist";
    }
  }
  
  public void printAccountNumbers()
  {
    Iterator<Integer> it = accountNumberSet.iterator();
    System.out.println("Complete list account numbers");
    while (it.hasNext())
    {
      System.out.println(it.next());
    }
  }
  public String generatePin()
  {
    int nmrPinDigits = 4;
    String pin = new String();
    for(int i = 0; i < nmrPinDigits; i += 1)
    {
        //double rnd = Math.random();
        //rnd *= 9;
        //rnd += 1;
        //byte rndByte = (byte)rnd;
        //String rndStr = Byte.toString(rndByte);
        //pin += rndStr;
        pin += Byte.toString((byte)(Math.random()*9 +1));
    }
    return pin;
    }
}