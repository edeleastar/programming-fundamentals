
/**
 * Represents typical bank customer
 * 
 * @author jfitzgerald
 * 
 */
public class Customer
{
  String name;
  int accountNumber;
  int balance;

  public Customer(String name, int accountNumber, int balance)
  {
    this.name = name;
    this.accountNumber = accountNumber;
    this.balance = balance;
  }

}
