import java.util.ArrayList;
import java.util.Iterator;

public class DiaryTester
{

    //Positive tests
    
    //Question 1 Task 3
    public boolean checkDailyCapacity(int dayNmr)
    {
        return false;
    }
  
    //Question 1 Task 4
    public boolean checkDailyCapacity2(int dayNmr)
    {
        return false;
    }

    //Question 1 Task 5
    public boolean checkDailyCapacity3(int dayNmr)
    {
        return false;
    }
    //=====================================================================================
    
    public boolean oneHourAppointment()
    {
        Day day = new Day(1); 
        boolean testResult = true;

        Appointment appointm1 = new Appointment("Java lecture", 1);
        Appointment appointm2 = new Appointment("Java lab", 1);
        Appointment appointm3 = new Appointment("Database lecture", 1);

        testResult =    day.makeAppointment(10, appointm1) &&
        day.makeAppointment(11, appointm2) &&
        day.makeAppointment(12, appointm3);

        return testResult;
    }

    public boolean twoHourAppointment()
    {
        Day day = new Day(1);
        boolean testResult = true;
        Appointment appointm1 = new Appointment("Course board meet", 2); 
        testResult = day.makeAppointment(16, appointm1);//add at 4 p.m.
        return testResult;
    }

    public boolean multipleUseAppointmentObject()
    {
        Day day = new Day(1);
        boolean testResult = true;
        Appointment appointm1 = new Appointment("Course board meet", 2); 
        testResult = day.makeAppointment(16, appointm1) && //add at 4 p.m.
        day.makeAppointment(15, appointm1);//add same appointment at 5 p.m.
        return testResult;
    }

    public boolean systemCapacity()
    {
        Day day = new Day(1);
        boolean testResult = true;
        Appointment appointm1 = new Appointment("Course board meet", 1); 
        //add the same appointment throughout the entire day
        testResult =    day.makeAppointment(9, appointm1) &&  
        day.makeAppointment(10, appointm1) &&  
        day.makeAppointment(11, appointm1) && 
        day.makeAppointment(12, appointm1) && 
        day.makeAppointment(13, appointm1) && 
        day.makeAppointment(14, appointm1) && 
        day.makeAppointment(15, appointm1) &&  
        day.makeAppointment(16, appointm1) && 
        day.makeAppointment(17, appointm1); 
        return testResult;
    }

    //Negative tests

    public boolean doubleBooking()
    {     
        Day day = new Day(1);
        boolean testResult = true;
        Appointment appointm1 = new Appointment("Java lecture", 1);     
        Appointment appointm2 = new Appointment("Java lab", 1);   
        testResult =    day.makeAppointment(10, appointm1) && 
        day.makeAppointment(10, appointm1);     
        return testResult;
    }

    public boolean checkStartDayBoundary()
    {
        Day day = new Day(1);
        //check start day boundary by attempting 1 hour appointment beginning at 8am
        Appointment appointm1 = new Appointment("Course board meet", 1); 
        return day.makeAppointment(8, appointm1);
    }

    public boolean checkEndDayBoundary()
    {
        Day day = new Day(1);
        //check end day boundary by attempting 2 hour appointment beginning at 5pm
        Appointment appointm2 = new Appointment("Course board meet", 2); 
        return day.makeAppointment(17, appointm2);

    }
   
    public boolean capacityOverrun()
    {
        Day day = new Day(1);
        Appointment appointment = new Appointment("Capacity overrun test", Day.MAX_APPOINTMENTS_PER_DAY + 1);
        return day.makeAppointment(Day.START_OF_DAY, appointment);
    }
    
}