

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class DiaryTesterTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class DiaryTesterTest
{
    private DiaryTester diaryTester;

    /**
     * Default constructor for test class DiaryTesterTest
     */
    public DiaryTesterTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        diaryTester = new DiaryTester();
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    //Question 1 Task 3 (continued)
    @Test
    public void positiveTests()
    {

    }
    //=============================================================================
    @Test
    public void negativeTests()
    {
        assertEquals(false, diaryTester.doubleBooking());
        assertEquals(false, diaryTester.capacityOverrun());
    }
}


