public class Calendar {

    //Question 1 Task 1
    public static String dayName(int dayNumber) {
     
        String dayName = "";
        switch (dayNumber) {
            //TODO
        }
        return dayName;
    }
    
    //Question 1 Task 2
    public static String monthName(int monthNumber)
    {
        String monthName = "";
        switch (monthNumber) {
            //TODO
        }
        return monthName;
    }
}