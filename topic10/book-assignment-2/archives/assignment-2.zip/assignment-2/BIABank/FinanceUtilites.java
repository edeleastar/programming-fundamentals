
public class FinanceUtilites
{

    public FinanceUtilites()
    {
    }

    /**
     * Checks if all PIN digits in ascending order
     * If in ascending order the PIN is invalid
     * Otherwise the PIN is valid
     *
     * @param  a string representing the PIN
     * @return true if the PIN is valid else false
     */
    public static boolean isValidAscending(String pin)
    {
  
    }

    
    /**
     * Checks if all PIN digits in descending order
     * If in descending order the PIN is invalid
     * Otherwise the PIN is valid
     *
     * @param  a string representing the PIN
     * @return true if the PIN is valid else false
     */
    public static boolean isValidDescending(String pin)
    {
    
    }

    
    /**
     * Checks if all PIN digits in ascending or descending order
     * If in ascending or descending order the PIN is invalid
     * Otherwise the PIN is valid
     *
     * @param  a string representing the PIN
     * @return true if the PIN is valid else false
     */
    public static boolean isValidAscendingDescending(String pin)
    {

    }
}

