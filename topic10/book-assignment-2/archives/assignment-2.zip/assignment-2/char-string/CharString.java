
public class CharString
{
    //Question 3 Task 1
    public static boolean isLowerCase(char ch)
    {       
        return false;
    }

    //Question 3 Task 2
    public static boolean isUpperCase(char ch)
    {
        return false;
    }

    //Question 3 Task 3
    public static char toUpper(char ch)
    {
        return ' ';
    }

    //Question 3 Task 4
    public static int wordCount(String string)
    {
        return 0;
    }

    //Question 3 Task 5
    public static int characterCount(String string, char ch)
    {
        return 0;
    }

    //Question 3 Task 6  
    public static boolean isPalindrome(String string)
    {
       return false;

    }
    
    //Two helpers required for Task 6
    public static boolean isEqualIgnoreCase(char ch1, char ch2)
    {
        return false;
    }
    
    /**
     * Create a string, the reverse of string
     * @param the string to be reversed
     * @return a copy of string reversed
     */
    public static String reverse(String string)
    {
        return "";
    }
   
    public static void main(String[] args)
    {
        System.out.println("Task 1");
        System.out.println("a is lower case " + isLowerCase('a'));
        System.out.println("A is lower case " + isLowerCase('A'));
        
        System.out.println();
        System.out.println("Task 2");        
        System.out.println("a is upper case " + isUpperCase('a'));
        System.out.println("A is upper case " + isUpperCase('A'));
        
        System.out.println();
        System.out.println("Task 3");       
        System.out.println("a to uppper case is " + toUpper('a'));
        System.out.println("A to upper case is " + toUpper('A'));
        
        String s = "Able was I ere I saw Elba";
        
        System.out.println();
        System.out.println("Task 4");
        System.out.println("Word count is " + wordCount(s));
        
        char ch = 'a';
        System.out.println();
        System.out.println("Task 5");
        System.out.println("Number of  " + ch + " characters in " + s + " is " + characterCount(s, ch));
        
        System.out.println();
        System.out.println("Task 6");
        System.out.println(s + " is a palindrome? " + isPalindrome(s));        
    }
    
}
