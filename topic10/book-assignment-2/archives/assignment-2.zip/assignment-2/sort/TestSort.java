
public class TestSort
{
    public static void integerSort()
    {

        int[] a = {10,7,8,7,9};

        System.out.println("Unsorted");
        for (int element : a)
        {
            System.out.print(element + " ");
        }

        Sort.quadraticSort(a);

        System.out.println("\nSorted");
        for (int element : a)
        {
            System.out.print(element + " ");
        }
    }

public static void stringSort()
    {
        //Test string sort
        String[] s = {"ggg", "ddd", "eeeff", "aaa", "bbb", "xxx", "zzz", "ccc", "xabcdef", "iiiiiii"};
        System.out.print("\nBefore sorting: ");
        for(String str : s)
        {
            System.out.print(str + " ");
        }

        Sort.quadraticSort(s);

        System.out.print("\n After sorting: ");
        for(String str : s)
        {
            System.out.print(str + " ");
        }
    }
}
