public class Sort
{
    /**
     * Sort integers
     * A homespun quadratic sorting algorithm
     * Probably the worst sorting algorithm in the world
     * Best O(n2), Average O(n2), Worst O(n2)
     * Algorithmic code:
     * for i ← 0 to length(A)
     *     for j ← i to length(A)
     *         if( A[j] < A[i])
     *            swap A[j] and A[i]
     *         endif
     *     endfor
     * endfor
     *   

     * @param a the 1-d integer array to be sorted
     */
    public static void quadraticSort(int[] a)
    {
        for (int i = 0; i < a.length; i += 1)
        {
            for (int j = i; j < a.length; j += 1)
            {
                if (a[j] < a[i])
                {
                    swap(a, i, j);
                }
            }
        }
    } 

    public static void swap(int[] a, int to, int from)
    {
        int temp = a[to];
        a[to] = a[from];
        a[from] = temp;
    }

    //Question 3 Task 7
    public static void quadraticSort(String[] s)
    {
       //TODO
    }

    public static void swap(String[] s, int to, int from)
    {
       //TODO
    }
}

