import java.util.ArrayList;

public class MessageSort
{
    //Question 4 Task 8
    public static void quadraticSort(Message[] m)
    {
        //TODO... 
    }

    private static void swap(Message[] arMsg, int to, int from)
    {
        //TODO...
    }
    
    //Question 4 Task 9
    public static void quadraticSort(ArrayList<Message> m)
    {
        //TODO...
    }

    private static void swap(ArrayList<Message> list, int to, int from)
    {
        //TODO...
    }

}
