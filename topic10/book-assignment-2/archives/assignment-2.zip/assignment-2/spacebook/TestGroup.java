public class TestGroup {

	public static void main(String[] args) {

		User homer = new User("Homer", "Simpson", "homer@simpson.com", "secret");
		User barney = new User("Barney", "Gumble", "barney@gumble.com","secret");
		User bart = new User("Bart", "Simpson", "bart@simpson.com", "secret");
		User lisa = new User("Lisa", "Simpson", "lisa@simpson.com", "secret");
		User marge = new User("Marge", "Simpson", "marge@simpson.com", "secret");

		homer.addGroup("Friends");

		homer.addGroupMember("Friends", barney);
		homer.addGroupMember("Friends", bart);
		homer.addGroupMember("Friends", lisa);
		homer.addGroupMember("Friends", marge);

		Group group = homer.groups.get("Friends");

		System.out.println(group);
		System.out.println(homer);

	}

}
