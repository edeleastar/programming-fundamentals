public class Assignment
{
    int     id;
    String  subject;
    float   result;
    
    public Assignment(int id, String subject, float result)
    {
        this.id         = id;
        this.subject    = subject;
        this.result     = result;
    }
    
    public void display()
    {
        System.out.println("Assignment id: " + id + "   Subject: " + subject + "   Result: " + result);
    }
}
