import java.util.ArrayList;
import java.util.Iterator;

public class Notebook
{
    // Storage for an arbitrary number of notes.
    private ArrayList<String> notes;
    private ArrayList<Assignment> assignments;

    /**
     * Perform any initialization that is required for the
     * notebook.
     */
    public Notebook()
    {
        notes = new ArrayList<String>();
        assignments = new ArrayList<>();
    }
    
    public void initializeTestData()
    {
    
        notes = new ArrayList<String>() 
        {{
                add("Lab at 9am");
                add("Lecture at 10am");
                add("Break at 11.15am");
                add("Library at 11.30 till lunch");
                add("Lunch at 1pm");
        }};
    
    }
    
    public void initializeTestData2()
    {
    
        notes = new ArrayList<String>(); 
        notes.add("Lab at 9am");
        notes.add("Lecture at 10am");
        notes.add("Break at 11.15am");
        notes.add("Library at 11.30 till lunch");
        notes.add("Lunch at 1pm");
    }
     
    public void initializeAssignmentData()
    {
    
        assignments = new ArrayList<Assignment>() 
        {{
            add(new Assignment(1001, "Networking",     74.3f));
            add(new Assignment(1002, "Programming",    56.4f));
            add(new Assignment(1003, "WebDev",         85.6f));
            add(new Assignment(1004, "Security",       79.8f));
            add(new Assignment(1005, "Algorithms",     68.4f));                                
        }};
    
    }  
    
    public void listAssignments()
    {
        for(Assignment assignment : assignments)
        {
           assignment.display();
        }
    }
    
    /**
     * Store a new note into the notebook.
     * @param note The note to be stored.
     */
    public void storeNote(String note)
    {
        notes.add(note);
    }

    /**
     * @return The number of notes currently in the notebook.
     */
    public int numberOfNotes()
    {
        return notes.size();
    }

     /**
      * Show a note.
      * @param noteNumber The number of the note to be shown.
      */
     public void showNote(int noteNumber)
     {
        if(noteNumber >= 0 && noteNumber < numberOfNotes())
        {
            System.out.println(notes.get(noteNumber));
        }
        else 
        {
            System.out.println("Please enter valid note number");
        }
    }
   
    public void listNotesForEach()
    {
        for(String note: notes)
        {
            //System.out.println(note.getnote);
            System.out.println((notes.lastIndexOf(note) +1) + " " + note);
        }
    }
   
   public void listNotesWhile()
   {
        int index = 0;
        while(index < notes.size())
        {
           System.out.println((index+1) + " " + notes.get(index));
           index = index + 1;
        }
   }
   
        public void listNotesIterator()
        {
            Iterator<String> it = notes.iterator();
            while(it.hasNext())
            {
                String note = it.next();
                System.out.println((notes.lastIndexOf(note) +1) + " " + note);
            }
        }
        public void listNotesIterator2()
        {
            int index = 1;
            Iterator<String> it = notes.iterator();
            while(it.hasNext())
            {
                String note = it.next();
                System.out.println(index + " " + note);
                index += 1;
            }
        }
        public boolean search(String searchString)
        {
            Iterator<String> it = notes.iterator();
            while (it.hasNext())
            {
                String s = it.next();
                if (s.contains(searchString))
                {
                    return true;
                }
            }
            return false;
        }
        
        public void remove(int index) 
        {
            if(index >= 0 && index < notes.size()) 
            { 
                notes.remove(index);
            } 
            else
            {
                System.out.println("You requested removal of a non-existant note. Please enter a valid index");
            }
        }
        public void removeAll()
        {
            notes.clear();
        }
}
