import java.util.ArrayList;
import java.util.Iterator;

public class DemoArray
{
    private int [] intArray;
    private int size = 10;
    
    public DemoArray()
    {
        intArray = new int[size];
    }
    
    public void demoArray()
    {
        for(int i = 0; i < size; i += 1)
        {
            intArray[i] = 100 + i;
        }
        
         for(int i = 0; i < size; i += 1)
        {
            System.out.println("Element at index " + i + " is " + intArray[i]);
        }       
    }
    
    public void demoArray2()
    {
        
        int i = 0;
        while(i < size)
        {
            intArray[i] = 200 + 2*i;
            i += 1;
        }
        
        i = 0;
        while(i < size)
        {
            System.out.println("Element at index " + i + " is " + intArray[i]);
            i += 1;
        }       
    }
    
    public void demoArray3()
    {
        
        int i = 0;
        do
        {
            intArray[i] = 300 + 3*i;
            i += 1;
        }while(i < size);
        
        i = 0;
        do
        {
            System.out.println("Element at index " + i + " is " + intArray[i]);
            i += 1;
        } while(i < size);     
    }
    
    public void demoArray4()
    {
        ArrayList<Integer> list = new ArrayList<>();
        for(int i = 0; i < size; i +=1)
        {
            list.add(400 + 4*i);
        }
        
        Iterator<Integer> it = list.iterator();
        int index = 0;
        while(it.hasNext())
        {
            System.out.println("Element at index " + index + " is " + it.next());
            index += 1;
        }
        
    }
    
    public void demoArray4_b()
    {
        ArrayList<Integer> list = new ArrayList<>();
        for(int i = 0; i < size; i +=1)
        {
            list.add(400 + 4*i);
        }
        
        Iterator<Integer> it = list.iterator();
        while(it.hasNext())
        {
            Integer integer = it.next();
            int index = list.lastIndexOf(integer);
            System.out.println("Element at index " + index + " is " + integer);
        }
        
    }
}
