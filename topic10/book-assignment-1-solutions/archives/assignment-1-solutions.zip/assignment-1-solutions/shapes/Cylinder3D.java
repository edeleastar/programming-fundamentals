/**
 * Class to display a solid cylinder in three dimensions
 * A cylinder viewed in 3D will appear as elliptical top and bottom
 * We choose, arbitrarily, the minor diameter of the ellipse to be half the major diameter
 */
public class Cylinder3D
{
    //the basic cylinder
    private int diameter;
    private int height;
    //in 3 D the top and bottom will appear as ellipses
    private Ellipse top;
    private Ellipse base;
    //the wall will appear as a rectangle
    private Rectangle wall;
    //set the origin (x,y), the top left corner of imaginary rectangle
    //enclosing the elliptical top of cylinder
    int xPosition;
    int yPosition;
    
    public Cylinder3D(int diameter, int height)
    {
        this.diameter   = diameter;
        this.height     = height;
        
        xPosition = 0;
        yPosition = 0;
        
        initialize3D();
    }
    
    private void initialize3D()
    {
        //choose the origin of the cylinder as viewed in 3D at (0,0)
        //Recall that we have arbitrarily decided the minor diameter is half the major diameter
        //Note that the origin of the ellipse is top left corner of a containing rectangle
        //Therefore the y coord of origin of wall will be diameter/4
        top     = new Ellipse(diameter, diameter/2, xPosition, yPosition, "black");
        wall    = new Rectangle(diameter, height, xPosition, yPosition + diameter/4, "black");
        base    = new Ellipse(diameter, diameter/2, xPosition, yPosition + height, "black");
    }
    
    /**
     * Move the cylinder object to a new position described by (x,y)
     * Recall (x, y) is position of top-left corner of rectangle bounding the top elliptical end
     * of the right circular cylinder
     * 
     * @param x the x coordinate of the top-left corner of the top ellipse's bounding rectangle
     * @param y the y coordinate of the top-left corner of the top ellipse's bounding rectangle
     */
    public void moveTo(int x, int y)
    {
        //
        top.moveTo(x, y);
        wall.moveTo(x, y + diameter/4);
        base.moveTo(x, y          + height);
        
        //reinitialize the instance variables
        //to reflect the new position of the cylinder
        xPosition = x;
        yPosition = y;
    }
}
