/**
 * @file    Cylinder.java
 * @brief   This class describes a right circular cylinder and includes 
 *                  methods to calculate properties such as surface area and volume.
 * @version 1.0 April 1, 2014
 * @author  jfitzgerald
 */
public class Cylinder
{
    private Circle base;
    private int height;
    /**
     * Constructs a new Cylinder object defined by user-supplied parameters
     * @param height    the height of the right circular cylinder
     * @param base      reference to Circle object defining base of right circular cylinder
     */       
    public Cylinder(Circle base, int height)
    {
        this.base    = base;
        this.height  = height;
    }
      
    public int getDiameter()
    {
        return base.getDiameter();
    }
    /**
     * Calculates the volume of right circular cylinder object
     * @return volume of right circular cylinder
     */    
    public double volume()
    {
        return Math.PI*base.getDiameter()*base.getDiameter()*height/4.0;
    }

    /**
     * Calculates the volume of right circular cylinder object
     * @return volume of right circular cylinder
     */ 
    public double volume2()
    {
        return Math.PI*Math.pow(base.getDiameter(), 2)*height/4.0;
    }
    /**
     * Calculates the surface area of right circular cylinder object
     * @return surface area (including circular base and top) of right circular cylinder
     */ 
    public double surfaceArea()
    {
        return 2*base.area() + base.circumference()*height;
    }
    
}
