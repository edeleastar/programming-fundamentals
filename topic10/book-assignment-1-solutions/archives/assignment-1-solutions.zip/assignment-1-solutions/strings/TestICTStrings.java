public class TestICTStrings
{
    
    public static void test_all()
    {
        test_isEqualIgnoreCase();
        test_hasPrefix();
        test_length();
        test_toUpperCase();
        test_subString();
        test_reverse();
    }
    
    
    public static void test_isEqualIgnoreCase()
    {
        String s1 = "ICTSkills Studio";
        String s2 = "ictskills studio";
        System.out.println("isEqualIgnoreCase:  "+ICTStrings.isEqual(s1, s1));
    }
    
    public static void test_hasPrefix()
    {
        String s1 = "ICTSkills Studio";
        String prefix = "ICT";
        System.out.println("hasPrefix:  "+ICTStrings.hasPrefix(s1, prefix));
    }
    
    public static void test_length()
    {
        String s1 = "ICTSkills ";
        String s2 = "Studio";
        System.out.println("length:  "+ICTStrings.length(s1, s2));
    }
    public static void test_toUpperCase()
    {
        String s1 = "ictskills studio";
        System.out.println("toUpper:  "+ICTStrings.toUpper(s1));
    }
    
    public static void test_subString()
    {
      String s1 = "Able was I";
      int startIndex = 2;
      int endIndex =  8;
      System.out.println("subString:  "+ICTStrings.subString(s1, startIndex, endIndex));
    }
    
    public static void test_reverse()
    {
        String s1 = "able was I ere I saw elba";
        System.out.println("reverse:  "+ICTStrings.reverse(s1));
    }
}
