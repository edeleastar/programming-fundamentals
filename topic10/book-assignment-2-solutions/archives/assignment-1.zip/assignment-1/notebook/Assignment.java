public class Assignment
{

    
    public Assignment(int id, String subject, float result)
    {

    }
    
    public void display()
    {
        
    }
}
