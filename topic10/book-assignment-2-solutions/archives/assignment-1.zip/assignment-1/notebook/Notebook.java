import java.util.ArrayList;
import java.util.Iterator;

public class Notebook
{
    // Storage for an arbitrary number of notes.
    private ArrayList<String> notes;

    /**
     * Perform any initialization that is required for the
     * notebook.
     */
    public Notebook()
    {
        notes = new ArrayList<String>();
         
    }
     
    public void initializeAssignmentData()
    {
    
    }  
    
    public void listAssignments()
    {

    }

    public void listNotesForEach()
    {
        
    }
   
   public void listNotesWhile()
   {

   }
   
    public void listNotesIterator()
    {

    }
//========================================================
    public void initializeTestData()
    {
    
    }
    /**
     * Store a new note into the notebook.
     * @param note The note to be stored.
     */
    public void storeNote(String note)
    {
        notes.add(note);
    }

    /**
     * @return The number of notes currently in the notebook.
     */
    public int numberOfNotes()
    {
        return notes.size();
    }

     /**
      * Show a note.
      * @param noteNumber The number of the note to be shown.
      */
     public void showNote(int noteNumber)
     {
        if(noteNumber >= 0 && noteNumber < numberOfNotes())
        {
            System.out.println(notes.get(noteNumber));
        }
        else 
        {
            System.out.println("Please enter valid note number");
        }
    }

    public boolean search(String searchString)
    {
        Iterator<String> it = notes.iterator();
        while (it.hasNext())
        {
            String s = it.next();
            if (s.contains(searchString))
            {
                return true;
            }
        }
        return false;
    }
    
    public void remove(int index) 
    {
        if(index >= 0 && index < notes.size()) 
        { 
            notes.remove(index);
        } 
        else
        {
            System.out.println("You requested removal of a non-existant note. Please enter a valid index");
        }
    }
    public void removeAll()
    {
        notes.clear();
    }
}
