/**
 * Class to display a solid cylinder in three dimensions
 * A cylinder viewed in 3D will appear as elliptical top and bottom
 * We choose, arbitrarily, the minor diameter of the ellipse to be half the major diameter
 */
public class Cylinder3D
{
    //the basic cylinder
    private int diameter;
    private int height;
    
    //in 3 D the top and bottom will appear as ellipses
    private Ellipse top;
    private Ellipse base;
    //the wall will appear as a rectangle
    private Rectangle wall;

    //set the origin (x,y), the top left corner of imaginary rectangle
    //enclosing the elliptical top of cylinder
    int xPosition;
    int yPosition;
    
    public Cylinder3D(int diameter, int height)
    {
     
        //....
        
        initialize3D();
    }
    
    private void initialize3D()
    {
        //choose the origin of the cylinder as viewed in 3D at (0,0)
        //Recall that we have arbitrarily decided the minor diameter is half the major diameter
        //Note that the origin of the ellipse is top left corner of a containing rectangle
        //Therefore the y coord of origin of wall will be diameter/4
        
        //....

    }
    
    public void moveTo(int x, int y)
    {
       //....
    }
}
