public class Cylinder
{

       
    public Cylinder(Circle base, int height)
    {

    }
      
    public int getDiameter()
    {
        return 0;
    }
       
    public int getHeight()
    {
        return 0;
    }
    
    public double volume()
    {
        return 0;
    }
    
    public double surfaceArea()
    {
        return 0;
    }
    
}
