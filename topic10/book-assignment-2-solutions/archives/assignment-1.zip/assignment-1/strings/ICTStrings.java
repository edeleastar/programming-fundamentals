public class ICTStrings
{
    /**
     * Check is s1 is equal to s2
     * @param
     * @param
     * @return
     */
    public static boolean isEqual(String s1, String s2)
    {
        return false;
    }
    
    /**
     * Check is s1 is equal to s2 ignoring case
     * @param
     * @param
     * @return
     */
    public static boolean isEqualIgnoreCase(String s1, String s2)
    {
        return false;
    }
    
    /**
     * Check if s1 has prefix
     * @param
     * @param
     * @return
     */
    public static boolean hasPrefix(String s1, String prefix)
    {
        return false;
    }
    
    /**
     * Length string comprising concatenated strings s1 and s2
     * @param
     * @param
     * @return
     */
    public static int length(String s1, String s2)
    {
        return 0;
    }
    
    /**
     * Create string the uppercase version of s1
     * @param
     * @return
     */
    public static String toUpper(String s1)
    {
        return "TODO";
    }
    
    
    /**
     * Create substring of s1 from indexStart to indexEnd excluding indexEnd
     * That is: range is [indexStart, indexEnd)
     * Example String "Hello ICTSkills"
     * indexStart = 2;
     * indexEnd = 8;
     * substring is "llo IC"
     * @param
     * @return
     */
    public static String subString(String s1, int beginIndex, int endIndex)
    {
        return "TODO";
    }
    
    /**
     * Create a string, the reverse of s1
     * Hint: use StringBuilder
     * @param
     * @return
     */
    public static String reverse(String s1)
    {
        return "TODO";
    }
}
