import java.util.ArrayList;
import java.util.Iterator;

public class DemoArray
{
    private int [] intArray;
    private int size = 10;
    
    public DemoArray()
    {
           
    }
    
    public void demoArray()
    {
         
    }
    
    public void demoArray2()
    {
          
    }
    
    public void demoArray3()
    {
       
    }
    
    public void demoArray4()
    {
    
    }
}
